package de.radio;

import de.maxhenkel.voicechat.api.VoicechatConnection;
import de.maxhenkel.voicechat.api.VoicechatServerApi;
import de.maxhenkel.voicechat.api.audiochannel.StaticAudioChannel;
import de.maxhenkel.voicechat.api.opus.OpusEncoder;
import org.bukkit.entity.Player;

import java.io.EOFException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.locks.LockSupport;

/** Ein laufender Radio-Stream für genau einen Spieler. */
public class RadioSession implements Runnable {

    private static final int FRAME_SAMPLES = 960;           // 20 ms bei 48 kHz mono
    private static final long FRAME_NANOS = 20_000_000L;

    private final RadioPlugin plugin;
    private final VoicechatServerApi api;
    private final Player player;
    private final String name;
    private final String url;

    private volatile boolean running = true;
    private volatile Process process;

    public RadioSession(RadioPlugin plugin, VoicechatServerApi api, Player player, String name, String url) {
        this.plugin = plugin;
        this.api = api;
        this.player = player;
        this.name = name;
        this.url = url;
    }

    public void stop() {
        running = false;
        Process p = process;
        if (p != null) p.destroy();
    }

    @Override
    public void run() {
        OpusEncoder encoder = null;
        try {
            VoicechatConnection connection = api.getConnectionOf(player.getUniqueId());
            if (connection == null) {
                plugin.msg(player, "Du brauchst die Simple-Voice-Chat-Mod (und musst verbunden sein), um Radio zu hören.");
                return;
            }

            StaticAudioChannel channel = api.createStaticAudioChannel(
                    UUID.randomUUID(), api.fromServerLevel(player.getWorld()), connection);
            if (channel == null) {
                plugin.msg(player, "Audio-Kanal konnte nicht erstellt werden.");
                return;
            }
            encoder = api.createEncoder();

            double volume = plugin.getConfig().getDouble("volume", 0.6);
            String ffmpeg = plugin.getConfig().getString("ffmpeg-path", "ffmpeg");

            ProcessBuilder pb = new ProcessBuilder(
                    ffmpeg, "-nostdin", "-loglevel", "error",
                    "-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", "5",
                    "-i", url,
                    "-vn", "-ac", "1", "-ar", "48000",
                    "-af", String.format(Locale.ROOT, "volume=%.2f", volume),
                    "-f", "s16le", "pipe:1");
            pb.redirectError(ProcessBuilder.Redirect.DISCARD);
            process = pb.start();
            if (!running) {
                process.destroy();
                return;
            }

            plugin.msg(player, "Spiele jetzt: " + name + "  (stoppen mit /stopradio)");

            byte[] buf = new byte[FRAME_SAMPLES * 2];
            short[] pcm = new short[FRAME_SAMPLES];
            long next = System.nanoTime();

            try (InputStream in = process.getInputStream()) {
                while (running && player.isOnline()) {
                    int off = 0;
                    while (off < buf.length) {
                        int r = in.read(buf, off, buf.length - off);
                        if (r < 0) throw new EOFException();
                        off += r;
                    }
                    ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(pcm);
                    channel.send(encoder.encode(pcm));

                    next += FRAME_NANOS;
                    long wait = next - System.nanoTime();
                    if (wait > 0) {
                        LockSupport.parkNanos(wait);
                    } else if (wait < -200_000_000L) {
                        next = System.nanoTime(); // zu weit hinten, neu synchronisieren
                    }
                }
            }
        } catch (EOFException e) {
            if (running) plugin.msg(player, "Der Stream ist beendet oder nicht erreichbar: " + name);
        } catch (Exception e) {
            if (running) {
                plugin.msg(player, "Fehler beim Abspielen (ist ffmpeg installiert?): " + e.getMessage());
                plugin.getLogger().warning("Radio-Fehler: " + e);
            }
        } finally {
            running = false;
            if (encoder != null) encoder.close();
            Process p = process;
            if (p != null) p.destroy();
            plugin.sessionEnded(player.getUniqueId(), this);
        }
    }
}
