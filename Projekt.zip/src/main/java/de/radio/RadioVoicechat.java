package de.radio;

import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.VoicechatServerApi;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import de.maxhenkel.voicechat.api.events.VoicechatServerStartedEvent;

public class RadioVoicechat implements VoicechatPlugin {

    private volatile VoicechatServerApi serverApi;

    @Override
    public String getPluginId() {
        return "minecraft_radio";
    }

    @Override
    public void registerEvents(EventRegistration registration) {
        registration.registerEvent(VoicechatServerStartedEvent.class, e -> serverApi = e.getVoicechat());
    }

    public VoicechatServerApi getApi() {
        return serverApi;
    }
}
