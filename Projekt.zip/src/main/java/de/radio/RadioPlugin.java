package de.radio;

import de.maxhenkel.voicechat.api.BukkitVoicechatService;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class RadioPlugin extends JavaPlugin implements Listener, TabExecutor {

    private final Map<UUID, RadioSession> sessions = new ConcurrentHashMap<>();
    private RadioVoicechat voicechat;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        BukkitVoicechatService service = getServer().getServicesManager().load(BukkitVoicechatService.class);
        if (service == null) {
            getLogger().severe("Simple Voice Chat wurde nicht gefunden! Plugin wird deaktiviert.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        voicechat = new RadioVoicechat();
        service.registerPlugin(voicechat);

        getServer().getPluginManager().registerEvents(this, this);
        for (String c : List.of("start", "stopradio", "addradio")) {
            getCommand(c).setExecutor(this);
            getCommand(c).setTabCompleter(this);
        }
    }

    @Override
    public void onDisable() {
        sessions.values().forEach(RadioSession::stop);
        sessions.clear();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        RadioSession s = sessions.remove(e.getPlayer().getUniqueId());
        if (s != null) s.stop();
    }

    void sessionEnded(UUID id, RadioSession session) {
        sessions.remove(id, session);
    }

    void msg(CommandSender to, String text) {
        to.sendMessage(Component.text("[Radio] ", NamedTextColor.GOLD)
                .append(Component.text(text, NamedTextColor.YELLOW)));
    }

    // ---------- Sender-Verwaltung ----------

    private ConfigurationSection stations() {
        ConfigurationSection s = getConfig().getConfigurationSection("stations");
        return s != null ? s : getConfig().createSection("stations");
    }

    private static String normalize(String s) {
        return s.toLowerCase().replaceAll("[\\s_\\-]", "");
    }

    private String findStation(String wanted) {
        String n = normalize(wanted);
        for (String key : stations().getKeys(false)) {
            if (normalize(key).equals(n)) return key;
        }
        return null;
    }

    // ---------- Commands ----------

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        switch (cmd.getName().toLowerCase()) {
            case "start" -> handleStart(sender, args);
            case "stopradio" -> handleStop(sender);
            case "addradio" -> handleAdd(sender, args);
        }
        return true;
    }

    private void handleStart(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            msg(sender, "Nur Spieler können Radio hören.");
            return;
        }
        if (args.length == 0 || !args[0].equalsIgnoreCase("radio")) {
            msg(sender, "Benutzung: /start radio <sender>");
            return;
        }
        if (!player.hasPermission("radio.use")) {
            msg(sender, "Dafür hast du keine Berechtigung.");
            return;
        }
        if (args.length == 1) {
            msg(sender, "Verfügbare Sender: " + String.join(", ", stations().getKeys(false)));
            return;
        }
        if (voicechat.getApi() == null) {
            msg(sender, "Voice Chat ist noch nicht bereit, versuche es gleich nochmal.");
            return;
        }

        String wanted = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
        String key = findStation(wanted);
        if (key == null) {
            msg(sender, "Sender nicht gefunden: " + wanted + ". Liste mit /start radio");
            return;
        }

        RadioSession old = sessions.remove(player.getUniqueId());
        if (old != null) old.stop();

        RadioSession session = new RadioSession(this, voicechat.getApi(), player, key, stations().getString(key));
        sessions.put(player.getUniqueId(), session);
        getServer().getScheduler().runTaskAsynchronously(this, session);
    }

    private void handleStop(CommandSender sender) {
        if (!(sender instanceof Player player)) return;
        RadioSession s = sessions.remove(player.getUniqueId());
        if (s == null) {
            msg(sender, "Es läuft gerade kein Radio.");
        } else {
            s.stop();
            msg(sender, "Radio gestoppt.");
        }
    }

    private void handleAdd(CommandSender sender, String[] args) {
        if (!sender.isOp() && !sender.hasPermission("radio.admin")) {
            msg(sender, "Nur Operatoren dürfen Sender hinzufügen.");
            return;
        }
        if (args.length < 2) {
            msg(sender, "Benutzung: /addradio <streamurl> <name>");
            return;
        }
        String url = args[0];
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            msg(sender, "Die URL muss mit http:// oder https:// beginnen.");
            return;
        }
        String name = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).replace(".", "").trim();
        if (name.isEmpty()) {
            msg(sender, "Ungültiger Name.");
            return;
        }
        String existing = findStation(name);
        if (existing != null) getConfig().set("stations." + existing, null);
        getConfig().set("stations." + name, url);
        saveConfig();
        msg(sender, "Sender gespeichert: " + name);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        List<String> out = new ArrayList<>();
        if (cmd.getName().equalsIgnoreCase("start")) {
            if (args.length == 1) {
                out.add("radio");
            } else if (args.length >= 2 && args[0].equalsIgnoreCase("radio")) {
                String typed = args[args.length - 1].toLowerCase();
                for (String key : stations().getKeys(false)) {
                    String tc = key.replace(' ', '_');
                    if (tc.toLowerCase().startsWith(typed)) out.add(tc);
                }
            }
        }
        return out;
    }
}
