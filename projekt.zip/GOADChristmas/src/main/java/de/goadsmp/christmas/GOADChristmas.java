package de.goadsmp.christmas;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public final class GOADChristmas extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private final Map<UUID, List<ItemStack>> giveawayItems = new HashMap<>();
    private final Set<UUID> waitingWord = new HashSet<>();
    private boolean giveawayRunning;
    private boolean acceptingAnswers;
    private String giveawayWord = "";
    private List<ItemStack> activeGiveaway = new ArrayList<>();
    private boolean eventEnabled;
    private boolean donationsDistributed;
    private NamespacedKey menuKey;
    private final Random random = new Random();

    @Override public void onEnable() {
        saveDefaultConfig();
        menuKey = new NamespacedKey(this, "menu");
        eventEnabled = getConfig().getBoolean("settings.enabled", true);
        donationsDistributed = getConfig().getBoolean("state.donationsDistributed", false);
        Objects.requireNonNull(getCommand("weihnachten")).setExecutor(this);
        Objects.requireNonNull(getCommand("giveaway")).setExecutor(this);
        Objects.requireNonNull(getCommand("christmas")).setExecutor(this);
        Objects.requireNonNull(getCommand("christmas")).setTabCompleter(this);
        getServer().getPluginManager().registerEvents(this, this);
        startMaintenance();
        getLogger().info("GOADChristmas für Paper 1.21.1 aktiviert.");
    }

    @Override public void onDisable() { saveConfig(); }

    private String color(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }
    private ItemStack item(Material material, String name, String... lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(color(name));
        if (lore.length > 0) meta.setLore(Arrays.stream(lore).map(this::color).toList());
        stack.setItemMeta(meta);
        return stack;
    }
    private void tag(ItemStack stack, String value) {
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(menuKey, PersistentDataType.STRING, value);
        stack.setItemMeta(meta);
    }
    private String tag(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return "";
        return stack.getItemMeta().getPersistentDataContainer().getOrDefault(menuKey, PersistentDataType.STRING, "");
    }

    @EventHandler public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (eventEnabled) {
            player.sendMessage(color(getConfig().getString("messages.welcome", "&6Willkommen auf GOADSMP!")));
            player.sendMessage(color(getConfig().getString("messages.season", "&bDie Weihnachts-Season hat begonnen!")));
            player.sendMessage(color(getConfig().getString("messages.spawn", "&fDer Spawn ist verschneit. Nutze &e/Weihnachten&f!")));
            if (getConfig().getBoolean("settings.join-firework", true)) launchFirework(player.getLocation());
        }
    }

    private void launchFirework(Location location) {
        Firework firework = location.getWorld().spawn(location.clone().add(0, 1.5, 0), Firework.class);
        FireworkMeta meta = firework.getFireworkMeta();
        meta.addEffect(FireworkEffect.builder().withColor(Color.RED, Color.GREEN, Color.WHITE)
                .with(FireworkEffect.Type.BALL_LARGE).trail(true).flicker(true).build());
        meta.setPower(1);
        firework.setFireworkMeta(meta);
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (name.equals("weihnachten")) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Dieser Befehl ist nur ingame verfügbar."); return true; }
            openChristmas(player);
            return true;
        }
        if (name.equals("giveaway")) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Dieser Befehl ist nur ingame verfügbar."); return true; }
            if (!player.isOp()) { player.sendMessage(color("&cDafür benötigst du OP.")); return true; }
            if (giveawayRunning) { player.sendMessage(color("&cEs läuft bereits ein Giveaway.")); return true; }
            openGiveaway(player);
            return true;
        }
        if (name.equals("christmas")) {
            if (!sender.isOp()) { sender.sendMessage(color("&cDafür benötigst du OP.")); return true; }
            if (args.length == 0) { sender.sendMessage(color("&6/christmas reload|start|stop|distribute")); return true; }
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "reload" -> { reloadConfig(); eventEnabled = getConfig().getBoolean("settings.enabled", true); sender.sendMessage(color("&aKonfiguration neu geladen.")); }
                case "start" -> { eventEnabled = true; getConfig().set("settings.enabled", true); saveConfig(); sender.sendMessage(color("&aWeihnachtsevent aktiviert.")); }
                case "stop" -> { eventEnabled = false; getConfig().set("settings.enabled", false); saveConfig(); sender.sendMessage(color("&cWeihnachtsevent deaktiviert.")); }
                case "distribute" -> { distributeDonations(); sender.sendMessage(color("&aSpendenverteilung ausgelöst.")); }
                default -> sender.sendMessage(color("&cUnbekannter Befehl."));
            }
            return true;
        }
        return false;
    }

    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (command.getName().equalsIgnoreCase("christmas") && sender.isOp() && args.length == 1)
            return List.of("reload", "start", "stop", "distribute");
        return Collections.emptyList();
    }

    private void openChristmas(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, color("&c&lGOADSMP &8» &aWeihnachten"));
        for (int i = 0; i < 54; i++) inv.setItem(i, item(Material.GREEN_STAINED_GLASS_PANE, "&a "));
        inv.setItem(4, item(Material.SNOWBALL, "&b&lWeihnachts-Season", "&7Dein tägliches Geschenk wartet!"));
        LocalDate today = LocalDate.now(ZoneId.of(getConfig().getString("settings.timezone", "Europe/Berlin")));
        int day = today.getMonthValue() == 12 ? today.getDayOfMonth() : 0;
        for (int d = 1; d <= 24; d++) {
            Material material = d < day ? Material.GRAY_STAINED_GLASS_PANE : (d == day ? Material.CHEST : Material.RED_STAINED_GLASS_PANE);
            ItemStack door = item(material, (d < day ? "&7" : "&c") + "Adventskalender – Tag " + d,
                    d < day ? "&7Der Tag ist vorbei." : d == day ? "&eKlicke, um dein Geschenk abzuholen!" : "&7Noch nicht verfügbar.");
            tag(door, "day:" + d);
            inv.setItem(9 + ((d - 1) / 6) * 9 + ((d - 1) % 6), door);
        }
        int cards = player.getInventory().all(Material.PAPER).values().stream().mapToInt(ItemStack::getAmount).sum();
        inv.setItem(47, item(Material.WRITABLE_BOOK, "&e&lWeihnachtskarten", "&7Gesammelte Karten: &f" + cards));
        ItemStack donate = item(Material.CHEST, "&6&lGemeinsame Spenden", "&7Klicke, um Items zu spenden."); tag(donate, "donate"); inv.setItem(49, donate);
        ItemStack close = item(Material.BARRIER, "&cSchließen"); tag(close, "close"); inv.setItem(51, close);
        player.openInventory(inv);
    }

    private void openDonation(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, color("&6&lWeihnachtsspenden"));
        inv.setItem(49, item(Material.EMERALD, "&a&lSpende abgeben", "&7Lege deine Items oben hinein", "&7und klicke anschließend hier."));
        tag(inv.getItem(49), "donate-confirm");
        player.openInventory(inv);
    }

    private void openGiveaway(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, color("&d&lGiveaway vorbereiten"));
        inv.setItem(49, item(Material.LIME_CONCRETE, "&a&lFertig", "&7Items einlegen und hier klicken.")); tag(inv.getItem(49), "giveaway-finish");
        inv.setItem(53, item(Material.BARRIER, "&cAbbrechen")); tag(inv.getItem(53), "giveaway-cancel");
        player.openInventory(inv);
    }

    @EventHandler public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        String title = ChatColor.stripColor(event.getView().getTitle());
        if (title == null) return;
        if (title.contains("GOADSMP") && title.contains("Weihnachten")) {
            event.setCancelled(true);
            String clicked = tag(event.getCurrentItem());
            if (clicked.startsWith("day:")) claimDay(player, Integer.parseInt(clicked.substring(4)));
            else if (clicked.equals("donate")) openDonation(player);
            else if (clicked.equals("close")) player.closeInventory();
            return;
        }
        if (title.contains("Weihnachtsspenden")) {
            if (event.getRawSlot() >= 45) event.setCancelled(true);
            if (event.getRawSlot() == 49 && tag(event.getCurrentItem()).equals("donate-confirm")) {
                event.setCancelled(true);
                List<ItemStack> added = new ArrayList<>();
                for (int i = 0; i < 45; i++) { ItemStack stack = event.getInventory().getItem(i); if (stack != null && stack.getType() != Material.AIR) added.add(stack.clone()); }
                if (added.isEmpty()) { player.sendMessage(color("&cDu hast keine Items eingelegt.")); return; }
                List<ItemStack> all = getConfig().getItemStackList("donations", new ArrayList<>());
                all.addAll(added); getConfig().set("donations", all); saveConfig();
                event.getInventory().clear(); player.closeInventory(); player.sendMessage(color("&aDanke für deine Weihnachtsspende!"));
            }
            return;
        }
        if (title.contains("Giveaway vorbereiten")) {
            if (event.getRawSlot() >= 45) event.setCancelled(true);
            if (event.getRawSlot() == 49 && tag(event.getCurrentItem()).equals("giveaway-finish")) {
                event.setCancelled(true);
                List<ItemStack> items = new ArrayList<>();
                for (int i = 0; i < 45; i++) { ItemStack stack = event.getInventory().getItem(i); if (stack != null && stack.getType() != Material.AIR) items.add(stack.clone()); }
                if (items.isEmpty()) { player.sendMessage(color("&cLege zuerst Giveaway-Items hinein.")); return; }
                giveawayItems.put(player.getUniqueId(), items); waitingWord.add(player.getUniqueId()); event.getInventory().clear(); player.closeInventory();
                player.sendMessage(color("&d&lGIVEAWAY &8» &fSchreibe jetzt das geheime Gewinnwort in den Chat. Nur das Plugin liest diese Nachricht."));
            } else if (event.getRawSlot() == 53 && tag(event.getCurrentItem()).equals("giveaway-cancel")) {
                event.setCancelled(true); player.closeInventory();
            }
        }
    }

    @EventHandler public void onClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        String title = ChatColor.stripColor(event.getView().getTitle());
        if (title == null || !(title.contains("Weihnachtsspenden") || title.contains("Giveaway vorbereiten"))) return;
        Inventory top = event.getInventory();
        for (int slot = 0; slot < 45; slot++) {
            ItemStack stack = top.getItem(slot);
            if (stack == null || stack.getType() == Material.AIR) continue;
            Map<Integer, ItemStack> leftovers = player.getInventory().addItem(stack.clone());
            leftovers.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
        }
        top.clear();
    }

    @EventHandler public void onDrag(InventoryDragEvent event) {
        String title = ChatColor.stripColor(event.getView().getTitle());
        if (title == null) return;
        if ((title.contains("Weihnachtsspenden") || title.contains("Giveaway vorbereiten")) && event.getRawSlots().stream().anyMatch(slot -> slot >= 45)) event.setCancelled(true);
        if (title.contains("GOADSMP") && title.contains("Weihnachten")) event.setCancelled(true);
    }

    @EventHandler public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        UUID id = player.getUniqueId();
        if (waitingWord.contains(id)) {
            event.setCancelled(true);
            String word = event.getMessage().trim();
            if (word.isEmpty() || word.length() > 32 || word.contains(" ")) { player.sendMessage(color("&cBitte ein einzelnes Wort mit maximal 32 Zeichen eingeben.")); return; }
            waitingWord.remove(id);
            List<ItemStack> items = giveawayItems.remove(id);
            Bukkit.getScheduler().runTask(this, () -> beginGiveaway(player, word, items));
            return;
        }
        if (giveawayRunning && acceptingAnswers && event.getMessage().trim().equalsIgnoreCase(giveawayWord)) {
            event.setCancelled(true);
            Bukkit.getScheduler().runTask(this, () -> winGiveaway(player));
        }
    }

    private void beginGiveaway(Player owner, String word, List<ItemStack> items) {
        if (items == null || items.isEmpty() || giveawayRunning) return;
        giveawayWord = word; activeGiveaway = items; giveawayRunning = true; acceptingAnswers = false;
        Bukkit.broadcastMessage(color("&d&lGIVEAWAY &8» &fEin Giveaway startet! Macht euch bereit."));
        int seconds = Math.max(1, getConfig().getInt("settings.giveaway-countdown", 5));
        new BukkitRunnable() {
            int remaining = seconds;
            @Override public void run() {
                if (!giveawayRunning) { cancel(); return; }
                if (remaining > 0) { Bukkit.broadcastMessage(color("&d&lGIVEAWAY &8» &e" + remaining)); remaining--; }
                else { acceptingAnswers = true; Bukkit.broadcastMessage(color("&a&lGO! &8» &fDas gesuchte Wort lautet: &e" + giveawayWord)); cancel(); }
            }
        }.runTaskTimer(this, 0L, 20L);
    }

    private void winGiveaway(Player winner) {
        if (!giveawayRunning || !acceptingAnswers) return;
        acceptingAnswers = false;
        for (ItemStack stack : activeGiveaway) {
            Map<Integer, ItemStack> leftovers = winner.getInventory().addItem(stack.clone());
            leftovers.values().forEach(item -> winner.getWorld().dropItemNaturally(winner.getLocation(), item));
        }
        Bukkit.broadcastMessage(color("&6&lGIVEAWAY &8» &a" + winner.getName() + " &fhat gewonnen! Glückwunsch!"));
        for (int i = 0; i < 8; i++) launchFirework(winner.getLocation());
        giveawayRunning = false; giveawayWord = ""; activeGiveaway.clear();
    }

    private void claimDay(Player player, int day) {
        ZoneId zone = ZoneId.of(getConfig().getString("settings.timezone", "Europe/Berlin"));
        LocalDate today = LocalDate.now(zone);
        if (today.getMonthValue() != 12 || day != today.getDayOfMonth() || day > 24) { player.sendMessage(color("&cDieses Türchen ist heute nicht verfügbar.")); return; }
        String claimKey = "claims." + player.getUniqueId() + "." + today;
        if (getConfig().getBoolean(claimKey, false)) { player.sendMessage(color("&cDu hast dein heutiges Geschenk bereits abgeholt.")); return; }
        getConfig().set(claimKey, true); saveConfig();
        int chance = Math.max(0, Math.min(100, getConfig().getInt("settings.rank-chance-percent", 10)));
        if (random.nextInt(100) < chance) {
            grantChristmasRank(player);
            Bukkit.broadcastMessage(color("&6&lWEIHNACHTS-JACKPOT &8» &e" + player.getName() + " &fhat den &cChristmas-Rang &fgewonnen!"));
        } else {
            Material[] pool = {Material.DIAMOND, Material.EMERALD, Material.GOLD_INGOT, Material.IRON_INGOT, Material.COOKED_BEEF, Material.EXPERIENCE_BOTTLE, Material.PAPER, Material.SNOWBALL, Material.CAKE, Material.GOLDEN_APPLE};
            Material reward = pool[random.nextInt(pool.length)];
            int amount = reward == Material.DIAMOND ? 1 + random.nextInt(2) : 2 + random.nextInt(9);
            Map<Integer, ItemStack> leftovers = player.getInventory().addItem(new ItemStack(reward, amount));
            leftovers.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
            player.sendMessage(color("&aDein Adventsgeschenk: &e" + amount + "x " + reward.name()));
        }
        player.closeInventory();
    }

    // Adds Christmas as an additional parent; it does not replace the player's existing rank(s).
    // The plugin itself dispatches LuckPerms commands as the server console.
    private void grantChristmasRank(Player player) {
        String group = getConfig().getString("settings.christmas-rank-group", "Christmas");
        String safeName = player.getName();
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp user " + safeName + " parent add " + group);
        String path = "rankedPlayers." + player.getUniqueId();
        getConfig().set(path + ".name", safeName);
        getConfig().set(path + ".expires", LocalDate.now(ZoneId.of(getConfig().getString("settings.timezone", "Europe/Berlin"))).plusDays(1).toString());
        saveConfig();
        player.sendMessage(color("&aDu hast den Christmas-Rang gewonnen!"));
    }

    private void expireChristmasRanks() {
        if (getConfig().getConfigurationSection("rankedPlayers") == null) return;
        ZoneId zone = ZoneId.of(getConfig().getString("settings.timezone", "Europe/Berlin"));
        LocalDate today = LocalDate.now(zone);
        for (String id : new ArrayList<>(getConfig().getConfigurationSection("rankedPlayers").getKeys(false))) {
            String path = "rankedPlayers." + id;
            String expires = getConfig().getString(path + ".expires", "9999-12-31");
            if (today.isBefore(LocalDate.parse(expires))) continue;
            String playerName = getConfig().getString(path + ".name", "");
            if (!playerName.matches("[A-Za-z0-9_]{1,16}")) { getLogger().warning("Ungültiger gespeicherter Spielername für Rangablauf: " + id); continue; }
            String group = getConfig().getString("settings.christmas-rank-group", "Christmas");
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp user " + playerName + " parent remove " + group);
            getConfig().set(path, null);
            Player online = Bukkit.getPlayer(UUID.fromString(id));
            if (online != null) online.sendMessage(color("&eDein Christmas-Rang ist ausgelaufen. Deine vorherigen Ränge bleiben erhalten."));
        }
        saveConfig();
    }

    private void startMaintenance() {
        new BukkitRunnable() { @Override public void run() {
            expireChristmasRanks();
            if (donationsDistributed || Bukkit.getOnlinePlayers().isEmpty()) return;
            ZoneId zone = ZoneId.of(getConfig().getString("settings.timezone", "Europe/Berlin"));
            LocalDateTime now = LocalDateTime.now(zone);
            String date = getConfig().getString("settings.distribution-date", "12-24");
            String time = getConfig().getString("settings.distribution-time", "18:00");
            if (now.format(DateTimeFormatter.ofPattern("MM-dd")).equals(date) && now.format(DateTimeFormatter.ofPattern("HH:mm")).equals(time)) distributeDonations();
        }}.runTaskTimer(this, 20L, 1200L);
    }

    private void distributeDonations() {
        List<Player> players = new ArrayList<>(Bukkit.getOnlinePlayers());
        if (players.isEmpty()) { Bukkit.broadcastMessage(color("&cDie Spendenverteilung wartet, bis Spieler online sind.")); return; }
        List<ItemStack> donated = getConfig().getItemStackList("donations", new ArrayList<>());
        if (donated.isEmpty()) {
            Bukkit.broadcastMessage(color("&eEs gibt keine Weihnachtsspenden."));
            donationsDistributed = true; getConfig().set("state.donationsDistributed", true); saveConfig(); return;
        }
        List<ItemStack> units = new ArrayList<>();
        for (ItemStack stack : donated) {
            if (stack == null || stack.getType() == Material.AIR) continue;
            int amount = stack.getAmount();
            while (amount > 0) { int count = Math.min(amount, stack.getMaxStackSize()); ItemStack part = stack.clone(); part.setAmount(count); units.add(part); amount -= count; }
        }
        Collections.shuffle(units);
        for (int i = 0; i < units.size(); i++) {
            Player target = players.get(i % players.size());
            Map<Integer, ItemStack> leftovers = target.getInventory().addItem(units.get(i));
            leftovers.values().forEach(item -> target.getWorld().dropItemNaturally(target.getLocation(), item));
        }
        getConfig().set("donations", new ArrayList<>());
        donationsDistributed = true; getConfig().set("state.donationsDistributed", true); saveConfig();
        Bukkit.broadcastMessage(color("&6&lGOADSMP &8» &aDie Weihnachtsspenden wurden gerecht an alle Online-Spieler verteilt! &c🎄"));
    }
}
