# GOADChristmas 1.1.0

Weihnachts-Event-Plugin für Paper 1.21.1 und Java 21.

## Build

Im Projektordner mit Gradle 8.8+ und Java 21:

```bash
gradle build
```

Die JAR liegt danach unter `build/libs/GOADChristmas.jar`.

## Befehle und Rechte

- `/weihnachten` – für alle Spieler
- `/giveaway` – ausschließlich für OP-Spieler
- `/christmas reload|start|stop|distribute` – ausschließlich für OP-Spieler

Die OP-Prüfung erfolgt über `Player#isOp()` bzw. `CommandSender#isOp()`.

## LuckPerms-Rang

LuckPerms muss installiert sein und die Gruppe `Christmas` muss existieren. Bei einem 10%-Gewinn führt das Plugin selbst über den Server-Console-Sender aus:

```text
lp user SPIELER parent add Christmas
```

Der bestehende Rang wird nicht ersetzt. Die Gruppe `Christmas` wird als zusätzliche Parent-Gruppe hinzugefügt und am Folgetag (also nach dem 24. Dezember spätestens am 25. Dezember) automatisch mit `parent remove Christmas` entfernt. Dadurch bleiben vorhandene Gruppen erhalten. Es wird keine LuckPerms-API verwendet und kein OP muss online sein.

## Funktionen

- Join-Begrüßung und Feuerwerk
- Adventskalender: tägliche Belohnung, einmal pro Spieler und Tag; konfigurierbare 10%-Chance auf Christmas
- Spenden-GUI und automatische gleichmäßige Verteilung an alle zum Verteilungszeitpunkt online befindlichen Spieler
- OP-Giveaway-GUI, geheimes Wort, 5-1-GO-Countdown, erster richtiger Chat-Treffer gewinnt
- OP-Verwaltung: Event starten/stoppen, Config neu laden, Spendenverteilung auslösen

## Hinweise

- Die Schneedecke bzw. Dekoration des Spawns muss in der Welt selbst vorbereitet werden; das Plugin sendet lediglich den Hinweis im Chat.
- Standardmäßige Verteilung: 24.12. um 18:00 Uhr, Zeitzone Europe/Berlin. In `config.yml` änderbar.
- Die Verteilung ist einmal pro Saison gespeichert. Für eine neue Saison `state.donationsDistributed` auf `false` setzen und Spenden leeren oder neu sammeln.
