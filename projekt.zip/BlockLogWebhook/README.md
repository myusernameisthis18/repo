# BlockLogWebhook (Paper 1.21.11)

Sendet jeden Blockabbau (BlockBreakEvent) gebündelt an einen Discord-Webhook.

## Bauen
Voraussetzung: JDK 21 + Maven
    mvn clean package
Die Datei liegt danach unter `target/BlockLogWebhook.jar` -> in den `plugins`-Ordner kopieren.

## Einrichten
1. Server einmal starten, `plugins/BlockLogWebhook/config.yml` öffnen.
2. `webhook-url` eintragen.
3. `/blocklog reload` und zum Testen `/blocklog test`.

## Befehle / Rechte
- `/blocklog reload` – Config neu laden (`blocklog.admin`, Standard: OP)
- `/blocklog test` – Testnachricht senden
- `blocklog.bypass` – Abbauten dieses Spielers werden nicht geloggt
