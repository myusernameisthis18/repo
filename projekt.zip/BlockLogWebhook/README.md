# BlockLogWebhook (Paper 1.21.11)

Sendet gebündelt an einen Discord-Webhook:
- Blöcke abbauen
- Blöcke platzieren
- Interaktionen (Rechtsklick auf Truhen, Türen, Knöpfe, Hebel, ...)
- Text, der auf Schilder geschrieben wird

## Bauen
    mvn clean package
Die JAR liegt danach unter `target/BlockLogWebhook.jar`.

## Einrichten
1. Server einmal starten, `plugins/BlockLogWebhook/config.yml` öffnen.
2. `webhook-url` eintragen.
3. `/blocklog reload` und zum Testen `/blocklog test`.
4. Bei Problemen `debug: true` setzen: dann erscheint jede Aktion auch in der Konsole.

## Befehle / Rechte
- `/blocklog reload` / `/blocklog test` (`blocklog.admin`, Standard: OP)
