package de.noahstudios.blocklog;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Sammelt Zeilen und sendet sie gebündelt (asynchron, in Reihenfolge) an einen Discord-Webhook.
 */
public final class WebhookSender {

    private static final int MAX_CONTENT = 1900; // Discord-Limit: 2000 Zeichen
    private static final Pattern RETRY_AFTER = Pattern.compile("\"retry_after\"\\s*:\\s*([0-9.]+)");

    private final Logger logger;
    private final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();
    private final ConcurrentLinkedQueue<String> queue = new ConcurrentLinkedQueue<>();
    private final AtomicInteger size = new AtomicInteger();
    private final AtomicInteger dropped = new AtomicInteger();
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "BlockLogWebhook-Sender");
        t.setDaemon(true);
        return t;
    });

    private volatile String url = "";
    private volatile String username = "BlockLog";
    private volatile String avatarUrl = "";
    private volatile int maxQueue = 5000;

    public WebhookSender(Logger logger) {
        this.logger = logger;
    }

    public void configure(String url, String username, String avatarUrl, int maxQueue) {
        this.url = url == null ? "" : url.trim();
        this.username = username == null || username.isBlank() ? "BlockLog" : username;
        this.avatarUrl = avatarUrl == null ? "" : avatarUrl.trim();
        this.maxQueue = Math.max(100, maxQueue);
    }

    public boolean isConfigured() {
        return url.startsWith("https://") && !url.contains("ID/TOKEN");
    }

    public void enqueue(String line) {
        if (size.get() >= maxQueue) {
            dropped.incrementAndGet();
            return;
        }
        queue.add(line);
        size.incrementAndGet();
    }

    /** Wird periodisch aufgerufen; sendet im Hintergrund-Thread. */
    public void flushAsync() {
        if (queue.isEmpty() && dropped.get() == 0) return;
        if (executor.isShutdown()) return;
        executor.submit(this::drainAndSend);
    }

    /** Sendet sofort eine einzelne Nachricht (z. B. für /blocklog test). */
    public void sendNow(String content) {
        if (executor.isShutdown()) return;
        executor.submit(() -> post(content));
    }

    public void drainAndSend() {
        if (!isConfigured()) {
            // Nichts senden, aber Queue nicht endlos wachsen lassen
            queue.clear();
            size.set(0);
            dropped.set(0);
            return;
        }

        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = queue.poll()) != null) {
            size.decrementAndGet();
            if (line.length() > MAX_CONTENT) line = line.substring(0, MAX_CONTENT);
            if (sb.length() + line.length() + 1 > MAX_CONTENT) {
                post(sb.toString());
                sb.setLength(0);
            }
            sb.append(line).append('\n');
        }

        int d = dropped.getAndSet(0);
        if (d > 0) {
            String note = "⚠️ " + d + " Einträge verworfen (Queue voll).";
            if (sb.length() + note.length() + 1 > MAX_CONTENT) {
                post(sb.toString());
                sb.setLength(0);
            }
            sb.append(note).append('\n');
        }

        if (sb.length() > 0) post(sb.toString());
    }

    public void shutdown() {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(10, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        // Restliche Einträge noch senden
        drainAndSend();
    }

    private void post(String content) {
        String json = "{\"content\":\"" + jsonEscape(content) + "\","
                + "\"username\":\"" + jsonEscape(username) + "\","
                + (avatarUrl.isEmpty() ? "" : "\"avatar_url\":\"" + jsonEscape(avatarUrl) + "\",")
                + "\"allowed_mentions\":{\"parse\":[]}}";

        for (int attempt = 0; attempt < 4; attempt++) {
            try {
                HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                        .timeout(Duration.ofSeconds(15))
                        .header("Content-Type", "application/json")
                        .POST(BodyPublishers.ofString(json, StandardCharsets.UTF_8))
                        .build();
                HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
                int code = response.statusCode();

                if (code >= 200 && code < 300) {
                    Thread.sleep(400); // kleine Pause zwischen Nachrichten (Rate-Limit)
                    return;
                }
                if (code == 429) {
                    long wait = 2000;
                    Matcher m = RETRY_AFTER.matcher(response.body());
                    if (m.find()) wait = (long) (Double.parseDouble(m.group(1)) * 1000) + 100;
                    Thread.sleep(Math.min(wait, 30_000));
                    continue;
                }
                logger.warning("Discord-Webhook antwortete mit HTTP " + code + ": " + response.body());
                return;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            } catch (Exception e) {
                logger.warning("Webhook-Fehler: " + e.getMessage());
                return;
            }
        }
        logger.warning("Webhook-Nachricht nach mehreren Versuchen verworfen (Rate-Limit).");
    }

    private static String jsonEscape(String s) {
        StringBuilder sb = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
                }
            }
        }
        return sb.toString();
    }
}
