package de.noahstudios.blocklog;

import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.block.Block;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class BlockLogPlugin extends JavaPlugin implements Listener {

    private WebhookSender sender;
    private BukkitTask flushTask;

    private final Set<Material> ignoredBlocks = EnumSet.noneOf(Material.class);
    private final Set<Material> onlyBlocks = EnumSet.noneOf(Material.class);
    private final Set<String> ignoredWorlds = new HashSet<>();

    private boolean logWorld;
    private boolean logCoords;
    private boolean logTool;
    private boolean ignoreCreative;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        sender = new WebhookSender(getLogger());
        getServer().getPluginManager().registerEvents(this, this);
        loadSettings();

        if (!sender.isConfigured()) {
            getLogger().warning("Keine gültige webhook-url in der config.yml gesetzt! Es wird nichts gesendet.");
        }
    }

    @Override
    public void onDisable() {
        if (flushTask != null) flushTask.cancel();
        if (sender != null) sender.shutdown();
    }

    private void loadSettings() {
        reloadConfig();
        FileConfiguration cfg = getConfig();

        sender.configure(
                cfg.getString("webhook-url", ""),
                cfg.getString("username", "BlockLog"),
                cfg.getString("avatar-url", ""),
                cfg.getInt("max-queue-size", 5000)
        );

        logWorld = cfg.getBoolean("log-world", true);
        logCoords = cfg.getBoolean("log-coordinates", true);
        logTool = cfg.getBoolean("log-tool", false);
        ignoreCreative = cfg.getBoolean("ignore-creative", false);

        ignoredBlocks.clear();
        onlyBlocks.clear();
        ignoredWorlds.clear();
        readMaterials(cfg.getStringList("ignored-blocks"), ignoredBlocks, "ignored-blocks");
        readMaterials(cfg.getStringList("only-blocks"), onlyBlocks, "only-blocks");
        for (String w : cfg.getStringList("ignored-worlds")) ignoredWorlds.add(w.toLowerCase(Locale.ROOT));

        if (flushTask != null) flushTask.cancel();
        long ticks = Math.max(1, cfg.getInt("batch-interval-seconds", 5)) * 20L;
        flushTask = getServer().getScheduler().runTaskTimerAsynchronously(this, sender::flushAsync, ticks, ticks);
    }

    private void readMaterials(List<String> names, Set<Material> target, String key) {
        for (String name : names) {
            Material m = Material.matchMaterial(name);
            if (m == null) {
                getLogger().warning("Unbekanntes Material in " + key + ": " + name);
            } else {
                target.add(m);
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        Material type = block.getType();

        if (player.hasPermission("blocklog.bypass")) return;
        if (ignoreCreative && player.getGameMode() == GameMode.CREATIVE) return;
        if (ignoredBlocks.contains(type)) return;
        if (!onlyBlocks.isEmpty() && !onlyBlocks.contains(type)) return;

        String worldName = block.getWorld().getName();
        if (ignoredWorlds.contains(worldName.toLowerCase(Locale.ROOT))) return;

        StringBuilder sb = new StringBuilder();
        sb.append("<t:").append(System.currentTimeMillis() / 1000L).append(":T> ⛏️ **")
                .append(escapeMarkdown(player.getName())).append("** hat `")
                .append(type.name()).append("` abgebaut");

        if (logWorld || logCoords) {
            sb.append(" —");
            if (logWorld) sb.append(" `").append(escapeMarkdown(worldName)).append("`");
            if (logCoords) {
                sb.append(" (").append(block.getX()).append(", ")
                        .append(block.getY()).append(", ")
                        .append(block.getZ()).append(")");
            }
        }
        if (logTool) {
            Material tool = player.getInventory().getItemInMainHand().getType();
            sb.append(" mit `").append(tool == Material.AIR ? "Hand" : tool.name()).append("`");
        }

        sender.enqueue(sb.toString());
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {
        if (!s.hasPermission("blocklog.admin")) {
            s.sendMessage("§cKeine Berechtigung.");
            return true;
        }
        if (args.length == 0) {
            s.sendMessage("§eVerwendung: /" + label + " <reload|test>");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                loadSettings();
                s.sendMessage("§aKonfiguration neu geladen." + (sender.isConfigured() ? "" : " §c(Webhook-URL fehlt!)"));
            }
            case "test" -> {
                if (!sender.isConfigured()) {
                    s.sendMessage("§cKeine gültige webhook-url in der config.yml.");
                } else {
                    sender.sendNow("✅ BlockLogWebhook Test von **" + escapeMarkdown(s.getName()) + "**");
                    s.sendMessage("§aTestnachricht wird gesendet…");
                }
            }
            default -> s.sendMessage("§eVerwendung: /" + label + " <reload|test>");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String o : List.of("reload", "test")) {
                if (o.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(o);
            }
        }
        return out;
    }

    private static String escapeMarkdown(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            if ("\\*_`~|>".indexOf(c) >= 0) sb.append('\\');
            sb.append(c);
        }
        return sb.toString();
    }
}
