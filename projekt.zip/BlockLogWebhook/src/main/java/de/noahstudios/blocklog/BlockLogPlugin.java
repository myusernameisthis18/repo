package de.noahstudios.blocklog;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class BlockLogPlugin extends JavaPlugin implements Listener {

    private WebhookSender sender;
    private BukkitTask flushTask;

    private final Set<Material> ignoredBlocks = EnumSet.noneOf(Material.class);
    private final Set<Material> onlyBlocks = EnumSet.noneOf(Material.class);
    private final Set<String> ignoredWorlds = new HashSet<>();
    private final Set<String> ignoredPlayers = new HashSet<>();

    private boolean logBreak, logPlace, logInteract, logSigns, logPhysical;
    private boolean interactOnlyInteractable;
    private boolean logWorld, logCoords, logTool, ignoreCreative, debug;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        sender = new WebhookSender(getLogger());
        getServer().getPluginManager().registerEvents(this, this);
        loadSettings();

        if (!sender.isConfigured()) {
            getLogger().warning("Keine gültige webhook-url in der config.yml gesetzt! Es wird nichts gesendet.");
        }
    }

    @Override
    public void onDisable() {
        if (flushTask != null) flushTask.cancel();
        if (sender != null) sender.shutdown();
    }

    private void loadSettings() {
        reloadConfig();
        FileConfiguration cfg = getConfig();

        sender.configure(
                cfg.getString("webhook-url", ""),
                cfg.getString("username", "BlockLog"),
                cfg.getString("avatar-url", ""),
                cfg.getInt("max-queue-size", 5000)
        );

        logBreak = cfg.getBoolean("log-break", true);
        logPlace = cfg.getBoolean("log-place", true);
        logInteract = cfg.getBoolean("log-interact", true);
        logSigns = cfg.getBoolean("log-signs", true);
        logPhysical = cfg.getBoolean("log-physical", false);
        interactOnlyInteractable = cfg.getBoolean("interact-only-interactable", true);

        logWorld = cfg.getBoolean("log-world", true);
        logCoords = cfg.getBoolean("log-coordinates", true);
        logTool = cfg.getBoolean("log-tool", false);
        ignoreCreative = cfg.getBoolean("ignore-creative", false);
        debug = cfg.getBoolean("debug", false);

        ignoredBlocks.clear();
        onlyBlocks.clear();
        ignoredWorlds.clear();
        ignoredPlayers.clear();
        readMaterials(cfg.getStringList("ignored-blocks"), ignoredBlocks, "ignored-blocks");
        readMaterials(cfg.getStringList("only-blocks"), onlyBlocks, "only-blocks");
        for (String w : cfg.getStringList("ignored-worlds")) ignoredWorlds.add(w.toLowerCase(Locale.ROOT));
        for (String p : cfg.getStringList("ignored-players")) ignoredPlayers.add(p.toLowerCase(Locale.ROOT));

        if (flushTask != null) flushTask.cancel();
        long ticks = Math.max(1, cfg.getInt("batch-interval-seconds", 5)) * 20L;
        flushTask = getServer().getScheduler().runTaskTimerAsynchronously(this, sender::flushAsync, ticks, ticks);
    }

    private void readMaterials(List<String> names, Set<Material> target, String key) {
        for (String name : names) {
            Material m = Material.matchMaterial(name);
            if (m == null) {
                getLogger().warning("Unbekanntes Material in " + key + ": " + name);
            } else {
                target.add(m);
            }
        }
    }

    // ------------------------------------------------------------------
    //  Filter
    // ------------------------------------------------------------------

    /** true = Aktion ignorieren (Spieler, Gamemode, Welt). */
    private boolean skipPlayerWorld(Player player, Block block) {
        if (ignoredPlayers.contains(player.getName().toLowerCase(Locale.ROOT))) return true;
        if (ignoreCreative && player.getGameMode() == GameMode.CREATIVE) return true;
        return ignoredWorlds.contains(block.getWorld().getName().toLowerCase(Locale.ROOT));
    }

    /** true = Block-Typ ignorieren (ignored-blocks / only-blocks). */
    private boolean skipMaterial(Material type) {
        if (ignoredBlocks.contains(type)) return true;
        return !onlyBlocks.isEmpty() && !onlyBlocks.contains(type);
    }

    // ------------------------------------------------------------------
    //  Events
    // ------------------------------------------------------------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        if (!logBreak) return;
        Player player = event.getPlayer();
        Block block = event.getBlock();
        if (skipPlayerWorld(player, block) || skipMaterial(block.getType())) return;

        emit(line(player, "⛏️", "hat `" + block.getType().name() + "` abgebaut", block, true));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (!logPlace) return;
        Player player = event.getPlayer();
        Block block = event.getBlockPlaced();
        if (skipPlayerWorld(player, block) || skipMaterial(block.getType())) return;

        emit(line(player, "🧱", "hat `" + block.getType().name() + "` platziert", block, true));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (!logInteract) return;

        Action action = event.getAction();
        boolean physical = action == Action.PHYSICAL;
        if (!physical && action != Action.RIGHT_CLICK_BLOCK) return;
        if (physical && !logPhysical) return;
        if (!physical && event.getHand() != EquipmentSlot.HAND) return; // Doppel-Events vermeiden

        Block block = event.getClickedBlock();
        if (block == null) return;
        if (!physical && event.useInteractedBlock() == Event.Result.DENY) return;

        Player player = event.getPlayer();
        if (!physical) {
            // Schleichend mit Item in der Hand wird der Block nicht benutzt, sondern platziert
            ItemStack item = event.getItem();
            if (player.isSneaking() && item != null && !item.getType().isAir()) return;
            if (interactOnlyInteractable && !block.getType().isInteractable()) return;
        }

        if (skipPlayerWorld(player, block) || skipMaterial(block.getType())) return;

        String text = (physical ? "hat `" : "hat mit `") + block.getType().name()
                + (physical ? "` ausgelöst" : "` interagiert");
        emit(line(player, "🖱️", text, block, true));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSignChange(SignChangeEvent event) {
        if (!logSigns) return;
        Player player = event.getPlayer();
        Block block = event.getBlock();
        if (skipPlayerWorld(player, block)) return;

        List<String> lines = new ArrayList<>();
        for (Component c : event.lines()) {
            lines.add(PlainTextComponentSerializer.plainText().serialize(c));
        }
        boolean empty = lines.stream().allMatch(String::isBlank);
        String text = empty ? "(leer)" : String.join(" | ", lines).replace("`", "'");
        String side = event.getSide().name().equals("BACK") ? "Rückseite" : "Vorderseite";

        String base = line(player, "🪧", "hat ein Schild beschriftet (" + side + ")", block, false);
        emit(base + ": `" + text + "`");
    }

    // ------------------------------------------------------------------
    //  Hilfsmethoden
    // ------------------------------------------------------------------

    private String line(Player player, String emoji, String text, Block block, boolean withTool) {
        StringBuilder sb = new StringBuilder();
        sb.append("<t:").append(System.currentTimeMillis() / 1000L).append(":T> ")
                .append(emoji).append(" **").append(escapeMarkdown(player.getName())).append("** ")
                .append(text);

        if (logWorld || logCoords) {
            sb.append(" —");
            if (logWorld) sb.append(" `").append(escapeMarkdown(block.getWorld().getName())).append("`");
            if (logCoords) {
                sb.append(" (").append(block.getX()).append(", ")
                        .append(block.getY()).append(", ")
                        .append(block.getZ()).append(")");
            }
        }
        if (withTool && logTool) {
            Material tool = player.getInventory().getItemInMainHand().getType();
            sb.append(" mit `").append(tool.isAir() ? "Hand" : tool.name()).append("`");
        }
        return sb.toString();
    }

    private void emit(String line) {
        if (debug) getLogger().info("[Log] " + line);
        sender.enqueue(line);
    }

    // ------------------------------------------------------------------
    //  Befehl
    // ------------------------------------------------------------------

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {
        if (!s.hasPermission("blocklog.admin")) {
            s.sendMessage("§cKeine Berechtigung.");
            return true;
        }
        if (args.length == 0) {
            s.sendMessage("§eVerwendung: /" + label + " <reload|test>");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                loadSettings();
                s.sendMessage("§aKonfiguration neu geladen." + (sender.isConfigured() ? "" : " §c(Webhook-URL fehlt!)"));
            }
            case "test" -> {
                if (!sender.isConfigured()) {
                    s.sendMessage("§cKeine gültige webhook-url in der config.yml.");
                } else {
                    sender.sendNow("✅ BlockLogWebhook Test von **" + escapeMarkdown(s.getName()) + "**");
                    s.sendMessage("§aTestnachricht wird gesendet…");
                }
            }
            default -> s.sendMessage("§eVerwendung: /" + label + " <reload|test>");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String o : List.of("reload", "test")) {
                if (o.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(o);
            }
        }
        return out;
    }

    private static String escapeMarkdown(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            if ("\\*_`~|>".indexOf(c) >= 0) sb.append('\\');
            sb.append(c);
        }
        return sb.toString();
    }
}
